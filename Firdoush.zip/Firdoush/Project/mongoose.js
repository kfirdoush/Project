const mongoose = require('mongoose'); //require mongoose
async function connectMongodb(url) { //give the url and connect mongodb with url
    return mongoose.connect(url);
    
}
module.exports = {
    connectMongodb, //exports the mongodb function
}