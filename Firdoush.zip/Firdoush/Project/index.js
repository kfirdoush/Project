const express = require('express');
const {connectMongodb} = require("./mongoose");
const app = express(); //create application
const urlRoute = require('./routes/url');//require current directory routes and url
const URL= require('./models/url'); //url require in model directory
const Port = 8005;
connectMongodb("mongodb://localhost:27017/short-url")//27017->port short-url->databasename connection with mongodb
.then(()=> console.log("Mongodb connected")); //then->listener apply because mongodb is proper connect or not
app.use(express.json());//middleware to pass incoming body ->url
app.use("/shorten",urlRoute);
app.get('/:shortId',async(req,res)=>{
const shortId = req.params.shortId;//user can give the shortId
const entry = await URL.findOneAndUpdate(
    { //find url and upadate date in numberof clicks
    shortId,
},
{
     $push:{
        numberofclicks:{
    timestamp:Date.now(),//show the date
        },
     },
}
);
res.redirect(entry.redirectURL);
});
app.listen(Port,console.log(`server started at ${Port}`));//string  convert into  literals
