const express = require('express');
const {NewShortUrl} = require("../controllers/url")// require controller file
const router = express.Router();
router.post("/",NewShortUrl);//path
module.exports = router; //exports the module router