const shortId = require("shortid"); //nanoid use
const URL=  require('../models/url'); //current directory use
async function NewShortUrl(req,res) { // async function
    const body = req.body; //user pass the origina url in body
    if(!body.url) return res.status(400).json({error:'url is required'}) //if body is not equal then return this msg as a json format
    const shortID = shortId();
    await URL.create({ //Id is created in Database
        shortId: shortID,
        redirectURL:body.url, //Give the origina url from user
        numberofclicks:[],
    });
    return res.json({id: shortID}); //give shortid to user  
}
module.exports = {
    NewShortUrl,
};
