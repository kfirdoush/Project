const mongoose = require('mongoose');
const urlSchema = new mongoose.Schema({//property
    shortId:{
       type:String,
       required:true,
       unique:true, //everyone has to be unique id
    },
    redirectURL:{ //Original Url
     type:String,
     require:true,
    },
    numberofclicks: [{ timestamp: { type: Number}}], //entry timings
},
{timestamp: true }
);
const URL = mongoose.model('shorten',urlSchema);//name url
module.exports = URL;// URL exports
